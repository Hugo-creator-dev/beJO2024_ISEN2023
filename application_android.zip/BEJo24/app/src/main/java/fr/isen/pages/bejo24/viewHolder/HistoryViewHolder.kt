package fr.isen.pages.bejo24.viewHolder

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.databinding.RvHistoryBinding

class HistoryViewHolder(binding: RvHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
    val zone: TextView = binding.rvHistoryZone
    val date: TextView = binding.rvHistoryDate
    val intensity: TextView = binding.rvHistoryIntensity
}