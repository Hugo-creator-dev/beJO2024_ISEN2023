package fr.isen.pages.bejo24

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import fr.isen.pages.bejo24.controller.AuthStateManager
import fr.isen.pages.bejo24.controller.Configuration
import net.openid.appauth.*
import java.util.concurrent.atomic.AtomicReference

class LoginActivity : AppCompatActivity() {
    private var mAuthService: AuthorizationService? = null
    private val mAuthRequest = AtomicReference<AuthorizationRequest?>()
    private var mStateManager: AuthStateManager? = null
    private var mConfiguration: Configuration? = null
    private var mUsePendingIntents = false
    private var TAG = "Connect"
    private val mClientId = AtomicReference<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mStateManager = AuthStateManager.getInstance(this)
        mConfiguration = Configuration.getInstance(this)
        if (mStateManager!!.current.isAuthorized
            && !mConfiguration!!.hasConfigurationChanged()
        ) {
            Log.i(TAG, "User is already authenticated, proceeding to token activity")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        } else {
            if (mConfiguration!!.hasConfigurationChanged()) {
                // discard any existing authorization state due to the change of configuration
                Log.i(TAG, "Configuration change detected, discarding old state")
                mStateManager!!.replace(AuthState())
                mConfiguration!!.acceptConfiguration()
            }
        }
        initializeAppAuth()

        setContentView(R.layout.activity_login)
    }

    fun onClick(view: View) {
        doAuth()
    }

    private fun handleConfigurationRetrievalResult(
        config: AuthorizationServiceConfiguration?,
        ex: AuthorizationException?
    ) {
        if (config == null) {
            Log.i(TAG, "Failed to retrieve discovery document", ex)
            return
        }
        Log.i(TAG, "Discovery document retrieved")
        mStateManager!!.replace(AuthState(config))
        initializeClient()
    }

    private fun createAuthRequest() {
        Log.i(TAG, "Creating auth request")
        val authRequestBuilder = AuthorizationRequest.Builder(
            mStateManager!!.current.authorizationServiceConfiguration!!,
            mClientId.get(),
            ResponseTypeValues.CODE,
            mConfiguration!!.redirectUri
        )
            .setScope(mConfiguration!!.scope)
        mAuthRequest.set(authRequestBuilder.build())
    }

    /**
     * Initiates a dynamic registration request if a client ID is not provided by the static
     * configuration.
     */
    private fun initializeClient() {
        if (mConfiguration?.clientId != null) {
            Log.i(TAG, "Using static client ID: " + mConfiguration!!.clientId)
            // use a statically configured client ID
            mClientId.set(mConfiguration!!.clientId)
            createAuthRequest()
            return
        }
        val lastResponse = mStateManager!!.current.lastRegistrationResponse
        if (lastResponse != null) {
            Log.i(TAG, "Using dynamic client ID: " + lastResponse.clientId)
            // already dynamically registered a client ID
            mClientId.set(lastResponse.clientId)
            createAuthRequest()
            return
        }

        // WrongThread inference is incorrect for lambdas
        // noinspection WrongThread
        Log.i(TAG, "Dynamically registering client")
        val registrationRequest = mConfiguration?.let { listOf(it.redirectUri) }?.let {
            RegistrationRequest.Builder(
                mStateManager!!.current.authorizationServiceConfiguration!!,
                it
            )
                .setTokenEndpointAuthenticationMethod(ClientSecretBasic.NAME)
                .build()
        }
        if (registrationRequest != null) {
            mAuthService!!.performRegistrationRequest(
                registrationRequest
            ) { response: RegistrationResponse?, ex: AuthorizationException? ->
                handleRegistrationResponse(
                    response,
                    ex
                )
            }
        }
    }

    private fun handleRegistrationResponse(
        response: RegistrationResponse?,
        ex: AuthorizationException?
    ) {
        mStateManager!!.updateAfterRegistration(response, ex)
        if (response == null) {
            Log.i(TAG, "Failed to dynamically register client", ex)

            return
        }
        Log.i(TAG, "Dynamically registered client: " + response.clientId)
        mClientId.set(response.clientId)
        createAuthRequest()

    }

    private fun initializeAppAuth() {
        Log.i(TAG, "Initializing AppAuth")
        recreateAuthorizationService()
        if (mStateManager!!.current.authorizationServiceConfiguration != null) {
            // configuration is already created, skip to client initialization
            Log.i(TAG, "auth config already established")
            initializeClient()
            return
        }

        Log.i(TAG, "Retrieving OpenID discovery doc")

        AuthorizationServiceConfiguration.fetchFromUrl(
            mConfiguration!!.discoveryUri!!,
            { config: AuthorizationServiceConfiguration?, ex: AuthorizationException? ->
                handleConfigurationRetrievalResult(
                    config,
                    ex
                )
            },
            mConfiguration!!.connectionBuilder
        )
    }

    private fun createAuthorizationService(): AuthorizationService {
        Log.i(TAG, "Creating authorization service")
        val builder = AppAuthConfiguration.Builder()
        mConfiguration?.let { builder.setConnectionBuilder(it.connectionBuilder) }
        return AuthorizationService(this, builder.build())
    }

    private fun recreateAuthorizationService() {
        if (mAuthService != null) {
            Log.i(TAG, "Discarding existing AuthService instance")
            mAuthService!!.dispose()
        }
        mAuthService = createAuthorizationService()
        mAuthRequest.set(null)
    }

    private fun doAuth() {
        if (mUsePendingIntents) {
            val completionIntent = Intent(this, MainActivity::class.java)
            val cancelIntent = Intent(this, LoginActivity::class.java)
            cancelIntent.putExtra(EXTRA_FAILED, true)
            cancelIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            val flags = PendingIntent.FLAG_IMMUTABLE
            mAuthService!!.performAuthorizationRequest(
                mAuthRequest.get()!!,
                PendingIntent.getActivity(this, 0, completionIntent, flags),
                PendingIntent.getActivity(this, 0, cancelIntent, flags)
            )
        } else {
            val intent = mAuthService!!.getAuthorizationRequestIntent(
                mAuthRequest.get()!!
            )
            startActivityForResult(intent, RC_AUTH)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_CANCELED) {

        } else {
            val intent = Intent(this, MainActivity::class.java)
            if (data != null) {
                intent.putExtras(data.extras!!)
            }
            startActivity(intent)
        }
    }

    companion object {
        private const val EXTRA_FAILED = "failed"
        private const val RC_AUTH = 100
    }

    override fun onDestroy() {
        super.onDestroy()
        mAuthService?.dispose()
    }
}