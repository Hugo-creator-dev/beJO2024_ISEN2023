package fr.isen.pages.bejo24.viewHolder

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.databinding.RvAdviceBinding

class AdviceViewHolder(binding : RvAdviceBinding) : RecyclerView.ViewHolder(binding.root) {
    val description: TextView = binding.rvAdviceDescription
    val titre: TextView = binding.rvAdviceNom
}