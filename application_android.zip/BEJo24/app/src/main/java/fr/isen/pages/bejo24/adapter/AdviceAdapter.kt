package fr.isen.pages.bejo24.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.viewHolder.AdviceViewHolder
import fr.isen.pages.bejo24.databinding.RvAdviceBinding
import fr.isen.pages.bejo24.model.Conseil

class AdviceAdapter(private val advices: List<Conseil>) : RecyclerView.Adapter<AdviceViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdviceViewHolder {
        return AdviceViewHolder(
            RvAdviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: AdviceViewHolder, position: Int) {
        val doctor = advices[position]
        holder.description.text = doctor.description
        holder.titre.text = doctor.titre
    }

    override fun getItemCount(): Int {
        return advices.size
    }
}