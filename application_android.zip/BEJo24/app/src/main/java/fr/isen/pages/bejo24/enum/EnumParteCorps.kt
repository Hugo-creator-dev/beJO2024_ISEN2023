package fr.isen.pages.bejo24.enum

enum class EnumParteCorps {
    Head,
    Belly,
    HandL,
    HandR,
    FootL,
    FootR,
    LegL,
    LegR,
    HarmL,
    HarmR,
    ShoulderL,
    ShoulderR
}