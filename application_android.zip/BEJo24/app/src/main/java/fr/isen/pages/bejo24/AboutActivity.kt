package fr.isen.pages.bejo24

import android.os.Bundle

class AboutActivity : MenuActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apropos)
    }
}