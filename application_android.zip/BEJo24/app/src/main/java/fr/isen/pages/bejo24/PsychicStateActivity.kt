package fr.isen.pages.bejo24

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import fr.isen.pages.bejo24.adapter.PsychicAdapter
import fr.isen.pages.bejo24.databinding.ActivityPsychiqueStateBinding
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.helper.TextValidatorHelper
import fr.isen.pages.bejo24.model.Psychique
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class PsychicStateActivity : MenuActivity() {
    private lateinit var binding: ActivityPsychiqueStateBinding
    private var listPsychics: List<Psychique> = ArrayList()
    private var listImpactsPossibles = listOf("++", "+", "-", "--")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPsychiqueStateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val btnValidatePsychic = binding.btnValidatePsychiqueState
        val addButton = binding.btnAddPsy
        addButton.setOnClickListener {
            CustomFormDialog(
                R.layout.dialog_add_psychique,
                ::actionButtonValid,
                ::actionValidationText,
                null,
                null,
                null
            ).show(supportFragmentManager, "test")
        }

        btnValidatePsychic.setOnClickListener {
            //get current date
            val formatter = SimpleDateFormat("yyyy/MM/dd", Locale.US)
            val date = Date()
            val current = formatter.format(date)

            //send value to bdd
            for (psychic in listPsychics) {
                if (psychic.impact != "") {
                    val impact = when (psychic.impact) {
                        "--" -> "0"
                        "-" -> "1"
                        "+" -> "2"
                        "++" -> "3"
                        else -> "0"
                    }

                    val jsonObject = JSONObject()
                    jsonObject.put("Date", current)
                    jsonObject.put("Position", "Mind")
                    jsonObject.put("Intensity", impact)
                    jsonObject.put("Injury_status", 0)

                    postSomeData("injuries", jsonObject) {
                        listPsychics = ArrayList()
                        display(listPsychics)
                    }
                }
            }
        }
    }

    private fun actionButtonValid(customView: View) {
        val facter = customView.findViewById<EditText>(R.id.dialogPsychiqueFacteur).text.toString()
        val facterToAdd = Psychique(
            nomFacteur = facter,
            impact = "+"
        )

        listPsychics = listPsychics + facterToAdd
        display(listPsychics)
    }

    private fun display(psychics: List<Psychique>) {
        binding.activityPsychiqueRV.layoutManager = LinearLayoutManager(this)
        binding.activityPsychiqueRV.adapter =
            PsychicAdapter(psychics, ::actionButtonPlus, ::actionButtonLess)
    }

    private fun actionButtonPlus(psychic: Psychique) {
        val currentImpact = psychic.impact
        if (currentImpact != listImpactsPossibles.last()) {
            val idCurrentImpact = listImpactsPossibles.indexOf(currentImpact)
            val newImpact = listImpactsPossibles[idCurrentImpact + 1]
            miseAJJourImpactPsychic(psychic, newImpact)
        }
    }

    private fun actionButtonLess(psychic: Psychique) {
        val currentImpact = psychic.impact
        if (currentImpact != listImpactsPossibles.first()) {
            val idCurrentImpact = listImpactsPossibles.indexOf(currentImpact)
            val newImpact = listImpactsPossibles[idCurrentImpact - 1]
            miseAJJourImpactPsychic(psychic, newImpact)
        }
    }

    private fun miseAJJourImpactPsychic(psychic: Psychique, impact: String) {
        val id = listPsychics.indexOf(psychic)
        listPsychics[id].impact = impact
        display(listPsychics)
    }

    private fun actionValidationText(customView: View, dialog: AlertDialog) {
        val dictionary = hashMapOf(
            R.id.dialogPsychiqueFacteur to false
        )

        dictionary.forEach {
            val textView = customView.findViewById<TextView>(R.id.dialogPsychiqueValidator)
            customView.findViewById<EditText>(it.key).addTextChangedListener(
                object : TextValidatorHelper(textView, dialog) {
                    override fun isFormValid(isTextValid: Boolean): Boolean {
                        dictionary[it.key] = isTextValid
                        return !dictionary.containsValue(false)
                    }
                }
            )
        }
    }
}