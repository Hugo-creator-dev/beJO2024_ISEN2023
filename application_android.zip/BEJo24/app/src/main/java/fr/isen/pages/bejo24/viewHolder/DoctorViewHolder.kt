package fr.isen.pages.bejo24.viewHolder

import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.databinding.RvDoctorBinding

class DoctorViewHolder(binding: RvDoctorBinding) : RecyclerView.ViewHolder(binding.root) {
    val nom: TextView = binding.rvDoctorNom
    val prenom: TextView = binding.rvDoctorPrenom
    val description: TextView = binding.rvDoctorDescription
    val communicationImg: ImageView = binding.rvDoctorImgCom
}