package fr.isen.pages.bejo24.viewHolder

import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.databinding.RvFacteurBinding

class PsychicViewHolder(binding: RvFacteurBinding) : RecyclerView.ViewHolder(binding.root) {
    val facteur: TextView = binding.rvFacteurNom
    val textChoice: TextView = binding.rvAdviceIntensity
    val minusButton: ImageView = binding.rvAdviceMoins
    val plusButton: ImageView = binding.rvAdvicePlus
}