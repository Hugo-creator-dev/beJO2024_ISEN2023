package fr.isen.pages.bejo24

import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import fr.isen.pages.bejo24.databinding.ActivityPhysiqueStateBinding
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.enum.EnumParteCorps
import fr.isen.pages.bejo24.enum.EnumSeekBar
import fr.isen.pages.bejo24.helper.EnumHelper
import fr.isen.pages.bejo24.model.Physique
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class PhysiqueStateActivity : MenuActivity() {
    private lateinit var binding: ActivityPhysiqueStateBinding
    private var selectedButton: EnumParteCorps? = null
    private var listPhysiques: List<Physique> = ArrayList()
    private var listSB = listOf(R.id.dialogPhysiqueSB)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhysiqueStateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val headButton = binding.btnHead
        val bellyButton = binding.btnBelly
        val handLButton = binding.btnHandL
        val handRButton = binding.btnHandR
        val footLButton = binding.btnFootL
        val footRButton = binding.btnFootR
        val legLButton = binding.btnLegL
        val legRButton = binding.btnLegR
        val harmLButton = binding.btnHarmL
        val harmRButton = binding.btnHarmR
        val shoulderLButton = binding.btnShoulderL
        val shoulderRButton = binding.btnShoulderR

        val btnValidatePhysique = binding.activityPhysiqueValider

        headButton.setOnClickListener {
            selectedButton = EnumParteCorps.Head
            dialog()
        }
        bellyButton.setOnClickListener {
            selectedButton = EnumParteCorps.Belly
            dialog()
        }
        handLButton.setOnClickListener {
            selectedButton = EnumParteCorps.HandL
            dialog()
        }
        handRButton.setOnClickListener {
            selectedButton = EnumParteCorps.HandR
            dialog()
        }
        footLButton.setOnClickListener {
            selectedButton = EnumParteCorps.FootL
            dialog()
        }
        footRButton.setOnClickListener {
            selectedButton = EnumParteCorps.FootR
            dialog()
        }
        legLButton.setOnClickListener {
            selectedButton = EnumParteCorps.LegL
            dialog()
        }
        legRButton.setOnClickListener {
            selectedButton = EnumParteCorps.LegR
            dialog()
        }
        harmLButton.setOnClickListener {
            selectedButton = EnumParteCorps.HarmL
            dialog()
        }
        harmRButton.setOnClickListener {
            selectedButton = EnumParteCorps.HarmR
            dialog()
        }
        shoulderLButton.setOnClickListener {
            selectedButton = EnumParteCorps.ShoulderL
            dialog()
        }
        shoulderRButton.setOnClickListener {
            selectedButton = EnumParteCorps.ShoulderR
            dialog()
        }

        btnValidatePhysique.setOnClickListener {
            //get current date
            val formatter = SimpleDateFormat("yyyy/MM/dd", Locale.US)
            val date = Date()
            val current = formatter.format(date)

            //send value to bdd
            for (physique in listPhysiques) {
                if (physique.intensite != 0) {
                    val jsonObject = JSONObject()
                    //jsonObject.put("Athlete_ID", getString(R.string.athleteID))
                    jsonObject.put("Date", current)
                    jsonObject.put("Position", physique.zoneDouleur)
                    jsonObject.put("Intensity", physique.intensite.toString())
                    jsonObject.put("Injury_status", 0)

                    postSomeData("injuries", jsonObject) {
                        finish()
                    }
                }
            }
        }
    }

    private fun dialog() {
        CustomFormDialog(
            R.layout.dialog_add_physique,
            ::actionButtonValid,
            null,
            listSB,
            ::actionChangeValue,
            null
        ).show(supportFragmentManager, "test")
    }

    private fun actionButtonValid(customView: View) {
        if (selectedButton == null) {
            return
        }

        val value = customView.findViewById<SeekBar>(R.id.dialogPhysiqueSB).progress
        val physique = Physique(
            zoneDouleur = selectedButton.toString(), intensite = value
        )
        listPhysiques = listPhysiques + physique

        var button: TextView? = null
        when (selectedButton) {
            EnumParteCorps.Head -> button = binding.btnHead
            EnumParteCorps.Belly -> button = binding.btnBelly
            EnumParteCorps.HandL -> button = binding.btnHandL
            EnumParteCorps.HandR -> button = binding.btnHandR
            EnumParteCorps.FootL -> button = binding.btnFootL
            EnumParteCorps.FootR -> button = binding.btnFootR
            EnumParteCorps.LegL -> button = binding.btnLegL
            EnumParteCorps.LegR -> button = binding.btnLegR
            EnumParteCorps.HarmL -> button = binding.btnHarmL
            EnumParteCorps.HarmR -> button = binding.btnHarmR
            EnumParteCorps.ShoulderL -> button = binding.btnShoulderL
            EnumParteCorps.ShoulderR -> button = binding.btnShoulderR
            else -> {}
        }
        button?.text = value.toString()
        button?.setBackgroundColor(getColor(R.color.white))
        selectedButton = null
    }

    private fun actionChangeValue(customView: View, enum: EnumSeekBar) {
        val idSeekbar = (object : EnumHelper() {}).convertEnumSeekBarToIdSeekBar(enum)
        val idText = (object : EnumHelper() {}).convertIdSeekBarToIdText(idSeekbar)
        val value = customView.findViewById<SeekBar>(idSeekbar).progress
        customView.findViewById<TextView>(idText).text = value.toString()
    }
}