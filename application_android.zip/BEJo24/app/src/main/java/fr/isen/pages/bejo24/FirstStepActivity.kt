package fr.isen.pages.bejo24

import android.os.Bundle
import android.view.View
import android.widget.EditText
import org.json.JSONObject


class FirstStepActivity : MenuActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_step)
    }

    fun validate(view: View)
    {
        val jsonObject = JSONObject()
        jsonObject.put(
            "Sport",
            //customView.findViewById<EditText>(R.id.dialogDoctorPrenom).text.toString()
            (findViewById<View>(R.id.sport)  as EditText).text.toString()
        )
        jsonObject.put(
            "Birth_Date",
            (findViewById<View>(R.id.date)  as EditText).text.toString()
        )
        jsonObject.put(
            "Sex",
            (findViewById<View>(R.id.genre)  as EditText).text.toString()
        )
        jsonObject.put(
            "Taille",
            (findViewById<View>(R.id.taille)  as EditText).text.toString()
        )

        postSomeData("identity", jsonObject) {
            finish()
        }
    }
}