package fr.isen.pages.bejo24.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.viewHolder.TrainingViewHolder
import fr.isen.pages.bejo24.databinding.RvTrainingBinding
import fr.isen.pages.bejo24.model.Training

class TrainingAdapter(private val trainings: List<Training>) :
    RecyclerView.Adapter<TrainingViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrainingViewHolder {
        return TrainingViewHolder(
            RvTrainingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: TrainingViewHolder, position: Int) {
        val training = trainings[position]
        holder.sport.text = training.sport
        holder.description.text = training.description
        holder.date.text = training.date
        holder.duree.text = training.duree
    }

    override fun getItemCount(): Int {
        return trainings.size
    }
}