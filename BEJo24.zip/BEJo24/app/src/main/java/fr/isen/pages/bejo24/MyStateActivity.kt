package fr.isen.pages.bejo24

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import fr.isen.pages.bejo24.databinding.ActivityMyStateBinding
import fr.isen.pages.bejo24.dialog.CustomViewDialog
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.enum.EnumSeekBar
import fr.isen.pages.bejo24.helper.EnumHelper
import fr.isen.pages.bejo24.helper.TextValidatorHelper
import fr.isen.pages.bejo24.model.General
import org.json.JSONObject

class MyStateActivity : MenuActivity() {
    private lateinit var binding: ActivityMyStateBinding
    private lateinit var general: General
    private var listSB = listOf(
        R.id.dialogGeneralSommeilSB,
        R.id.dialogGeneralFatigueSB,
        R.id.dialogGeneralCourbatureSB,
        R.id.dialogGeneralHumeurSB
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyStateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val physiqueButton = binding.activityStatePhysique
        val generalButton = binding.activityStateGeneral
        val psychicButton = binding.activityStatePsychologique
        val historyButton = binding.activityStateHistorique

        getScore()

        generalButton.setOnClickListener {
            CustomFormDialog(
                R.layout.dialog_add_general_physique,
                ::actionButtonValid,
                ::actionValidationText,
                listSB,
                ::actionChangeValue,
                null
            ).show(supportFragmentManager, "test")
        }
        physiqueButton.setOnClickListener {
            startActivity(Intent(this, PhysiqueStateActivity::class.java))
        }
        psychicButton.setOnClickListener {
            startActivity(Intent(this, PsychicStateActivity::class.java))
        }
        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun actionButtonValid(customView: View) {
        val sleepString =
            customView.findViewById<TextView>(R.id.dialogGeneralSommeilValeur).text.toString()
        val fatigueString =
            customView.findViewById<TextView>(R.id.dialogGeneralFatigueValeur).text.toString()
        val stiffnessString =
            customView.findViewById<TextView>(R.id.dialogGeneralCourbatureValeur).text.toString()
        val moodString =
            customView.findViewById<TextView>(R.id.dialogGeneralHumeurValeur).text.toString()

        general = General(
            sommeil = (object : EnumHelper() {}).convertEnumStatGeneralStringToInt(sleepString),
            fatigue = (object : EnumHelper() {}).convertEnumStatGeneralStringToInt(fatigueString),
            courbature = (object : EnumHelper() {}).convertEnumStatGeneralStringToInt(
                stiffnessString
            ),
            humeur = (object : EnumHelper() {}).convertEnumStatGeneralStringToInt(moodString),
            poids = customView.findViewById<TextView>(R.id.dialogGeneralPoidsValeur).text.toString()
        )

        val jsonObject = JSONObject()
        jsonObject.put("Sleep", general.sommeil.toString())
        jsonObject.put("General_tiredness", general.fatigue.toString())
        jsonObject.put("Aches_pains", general.courbature.toString())
        jsonObject.put("Mood_stress", general.humeur.toString())
        jsonObject.put("Weight", general.poids.toInt())

        postSomeData("selfeval", jsonObject) {response ->
            Log.i("o",response.toString())
            getScore()
        }
    }

    private fun actionValidationText(customView: View, dialog: AlertDialog) {
        val dictionary = hashMapOf(
            R.id.dialogGeneralPoidsValeur to false
        )

        dictionary.forEach {
            val textView = customView.findViewById<TextView>(R.id.dialogGeneralValidator)
            customView.findViewById<EditText>(it.key).addTextChangedListener(
                object : TextValidatorHelper(textView, dialog) {
                    override fun isFormValid(isTextValid: Boolean): Boolean {
                        dictionary[it.key] = isTextValid
                        return !dictionary.containsValue(false)
                    }
                }
            )
        }
    }

    private fun actionChangeValue(customView: View, enum: EnumSeekBar) {
        val idSeekbar = (object : EnumHelper() {}).convertEnumSeekBarToIdSeekBar(enum)
        val idText = (object : EnumHelper() {}).convertIdSeekBarToIdText(idSeekbar)
        val valueInt = customView.findViewById<SeekBar>(idSeekbar).progress
        val value = (object : EnumHelper() {}).convertIntToEnumStatGeneralString(valueInt)
        customView.findViewById<TextView>(idText).text = value
    }

    private fun getScore() {
        val iaScore = binding.activityStateIndicateur

        getSomeData("score") { response ->
            val scoreArray = response.getJSONArray("data")
            if (scoreArray.length() == 0) {
                iaScore.text = "."
            } else {
                val lastScore = scoreArray.getJSONArray(scoreArray.length() - 1)
                val score = lastScore[2].toString()
                iaScore.text = score
                checkScoreCritique(score.toInt())
            }
        }
    }

    private fun checkScoreCritique(value: Int) {
        if (value >= 5) {
            CustomViewDialog(R.layout.dialog_score_risque, null, null).show(
                supportFragmentManager,
                "test"
            )
        }
    }
}