package fr.isen.pages.bejo24

import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import fr.isen.pages.bejo24.adapter.AdviceAdapter
import fr.isen.pages.bejo24.databinding.ActivityAdviceBinding
import fr.isen.pages.bejo24.model.Conseil
import kotlin.random.Random

class AdviceActivity : MenuActivity() {
    private lateinit var binding: ActivityAdviceBinding
    private var listAdvices: List<Conseil> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdviceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getAdviceBdd()
        listAdvices = ArrayList()
    }

    private fun display() {
        listAdvices = listAdvices.sortedBy { it.titre }
        getDailyAdvice()
        binding.activityAdviceRV.layoutManager = LinearLayoutManager(this)
        binding.activityAdviceRV.adapter = AdviceAdapter(listAdvices)
        listAdvices = ArrayList()
    }

    private fun getAdviceBdd() {
        getSomeData("advice") { response ->
            val adviceArray = response.getJSONArray("data")
            if (adviceArray.length() != 0) {
                for (i in 0 until adviceArray.length()) {
                    val advices = adviceArray.getJSONArray(i)
                    val advice = Conseil(
                        description = advices[2].toString(), titre = advices[1].toString()
                    )

                    listAdvices = listAdvices + advice
                }
            }
            display()
        }
    }

    private fun getDailyAdvice() {
        if (listAdvices.isNotEmpty()) {
            val randomIndex = Random.nextInt(listAdvices.size)
            val advice =
                listAdvices[randomIndex].titre + " : " + listAdvices[randomIndex].description
            binding.activityAdviceConseilJour.text = advice
        }
    }
}