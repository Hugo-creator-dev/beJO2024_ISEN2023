package fr.isen.pages.bejo24.enum

enum class EnumStatGeneral {
    TresMauvais,
    Mauvais,
    Neutre,
    Bon,
    TresBon
}