package fr.isen.pages.bejo24.enum

enum class EnumSeekBar {
    Physique,
    Sommeil,
    Fatigue,
    Courbature,
    Humeur,
    Blessure,
    Default //never append
}