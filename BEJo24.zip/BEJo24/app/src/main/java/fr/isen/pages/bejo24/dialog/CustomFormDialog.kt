package fr.isen.pages.bejo24.dialog

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import androidx.fragment.app.DialogFragment
import fr.isen.pages.bejo24.enum.EnumSeekBar
import fr.isen.pages.bejo24.helper.EnumHelper

open class CustomFormDialog(
    val layout:Int,
    val fnPositiveButton:(customView:View) -> Unit,
    private val fnActionValidationChampsTexte:((customView:View, dialog:AlertDialog) -> Unit)?,
    private val seekBarIds: List<Int>?,
    val fnChangeValue:((customView:View, seekbar: EnumSeekBar) -> Unit)?,
    private val fnRemplissage: ((customView:View) -> Unit)?,
    ): DialogFragment() {
    private lateinit var customView: View

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            customView = requireActivity().layoutInflater.inflate(layout, null)

            gestionSeekBar()
            gestionSpinner()

            builder.setView(customView)
            builder.setPositiveButton("Valider") { _, _ ->
                fnPositiveButton(customView)
            }
            builder.setNegativeButton("Annuler") { _, _ ->

            }

            val dialog = builder.create()
            dialog.show()
            gestionValidationChampsTextes(dialog)
            return dialog
        }?: throw IllegalStateException("Activity cannot be null")
    }

    private fun gestionSeekBar(){
        if(seekBarIds != null && fnChangeValue != null){
            for(seekBarId in seekBarIds) {
                customView.findViewById<SeekBar>(seekBarId).setOnSeekBarChangeListener(
                    object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                            if (p0 == null) {
                                return
                            }
                            val enum = (object : EnumHelper() {}).convertIntToEnumSeekBar(p0.id)
                            fnChangeValue.invoke(customView, enum)
                        }

                        override fun onStartTrackingTouch(p0: SeekBar?) {}

                        override fun onStopTrackingTouch(p0: SeekBar?) {}
                    }
                )
            }
        }
    }

    private fun gestionSpinner(){
        fnRemplissage?.invoke(customView)
    }

    private fun gestionValidationChampsTextes(dialog: AlertDialog){
        if(fnActionValidationChampsTexte != null){
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
            fnActionValidationChampsTexte.invoke(customView, dialog)
        }
    }
}