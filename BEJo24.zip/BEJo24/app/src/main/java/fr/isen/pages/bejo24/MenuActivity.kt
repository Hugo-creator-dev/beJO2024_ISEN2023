package fr.isen.pages.bejo24

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import fr.isen.pages.bejo24.controller.AuthStateManager
import fr.isen.pages.bejo24.controller.Configuration
import fr.isen.pages.bejo24.dialog.CustomViewDialog
import net.openid.appauth.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.atomic.AtomicReference


open class MenuActivity// discard any existing authorization state due to the change of configuration
    : AppCompatActivity() {

    val END_SESSION_REQUEST_CODE = 911
    var mStateManager: AuthStateManager? = null
    private var mConfiguration: Configuration? = null
    val mUserInfoJson: AtomicReference<JSONObject> = AtomicReference()
    var mAuthService: AuthorizationService? = null
    val KEY_USER_INFO = "userInfo"
    private val TAG = "Token"
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        mStateManager = AuthStateManager.getInstance(this)
        mConfiguration = Configuration.getInstance(this)
        val config = Configuration.getInstance(this)
        if (config.hasConfigurationChanged()) {
            Toast.makeText(
                this, "Configuration change detected", Toast.LENGTH_SHORT
            ).show()
            signOut()
            return
        }

        mAuthService = AuthorizationService(
            this,
            AppAuthConfiguration.Builder().setConnectionBuilder(config.connectionBuilder).build()
        )

        if (savedInstanceState != null) {
            try {
                mUserInfoJson.set(savedInstanceState.getString(KEY_USER_INFO)
                    ?.let { JSONObject(it) })
            } catch (ex: JSONException) {
                Log.e(TAG, "Failed to parse saved user info JSON, discarding", ex)
            }
        }

        super.onCreate(savedInstanceState)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.imageHF -> {
            startActivity(Intent(this, AboutActivity::class.java))
            true
        }
        R.id.logOut -> {
            endSession()
            true
        }
        R.id.help -> {
            startActivity(Intent(this, HelpActivity::class.java))
            true
        }

        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }

    fun signOut() {
        // discard the authorization and token state, but retain the configuration and
        // dynamic client registration (if applicable), to save from retrieving them again.
        val currentState = mStateManager!!.current
        val clearedState = AuthState(currentState.authorizationServiceConfiguration!!)
        if (currentState.lastRegistrationResponse != null) {
            clearedState.update(currentState.lastRegistrationResponse)
        }
        mStateManager!!.replace(clearedState)
        val mainIntent = Intent(this, LoginActivity::class.java)
        mainIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(mainIntent)
        finish()
    }

    private fun endSession() {
        val currentState = mStateManager!!.current
        val config = currentState.authorizationServiceConfiguration
        if (config!!.endSessionEndpoint != null) {

            val endSessionRequest =
                EndSessionRequest.Builder(config).setIdTokenHint(currentState.idToken)
                    //.setPostLogoutRedirectUri(mConfiguration!!.endSessionRedirectUri)
                    .build()
            val mainIntent = Intent(this, LoginActivity::class.java)
            val clearedState = AuthState(currentState.authorizationServiceConfiguration!!)
            if (currentState.lastRegistrationResponse != null) {
                clearedState.update(currentState.lastRegistrationResponse)
            }
            mStateManager!!.replace(clearedState)
            mAuthService!!.performEndSessionRequest(
                endSessionRequest,
                PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_IMMUTABLE),
                PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_IMMUTABLE)
            )

        } else {
            signOut()
        }
    }

    fun exchangeAuthorizationCode(authorizationResponse: AuthorizationResponse, callback: ()-> Any) {
        performTokenRequest(
            authorizationResponse.createTokenExchangeRequest()
        ) { tokenResponse: TokenResponse?, authException: AuthorizationException? ->
            handleCodeExchangeResponse(
                tokenResponse, authException
            )
            callback()
        }
    }

    private fun performTokenRequest(
        request: TokenRequest, callback: AuthorizationService.TokenResponseCallback
    ) {
        val clientAuthentication: ClientAuthentication = try {
            mStateManager!!.current.clientAuthentication
        } catch (ex: ClientAuthentication.UnsupportedAuthenticationMethod) {
            Log.d(
                TAG,
                "Token request cannot be made, client authentication for the token " + "endpoint could not be constructed (%s)",
                ex
            )
            return
        }
        mAuthService!!.performTokenRequest(
            request, clientAuthentication, callback
        )
    }

    private fun handleCodeExchangeResponse(
        tokenResponse: TokenResponse?, authException: AuthorizationException?
    ) {
        mStateManager!!.updateAfterTokenResponse(tokenResponse, authException)
        if (!mStateManager!!.current.isAuthorized) {
            val message =
                ("Authorization Code exchange failed" + if (authException != null) authException.error else "")

            // WrongThread inference is incorrect for lambdas

        } else {

        }
    }

    fun getSomeData(
        path: String, settings: String = "", fnResponse: Response.Listener<JSONObject>
    ) {
        mStateManager!!.current.performActionWithFreshTokens(
            mAuthService!!
        ) { accessToken: String?, idToken: String?, ex: AuthorizationException? ->

            if (accessToken == null) {
                Log.e(TAG, "Token refresh failed when fetching user info")
                mUserInfoJson.set(null)
            } else {
                val queue = Volley.newRequestQueue(this)

                Log.i("zertydfge", mStateManager!!.current.isAuthorized.toString())


                val request = JsonObjectRequest(
                    Request.Method.GET,
                    mConfiguration?.restApiUrl.toString() + path + "?access_token=" + accessToken + "&" + settings,
                    JSONObject(),
                    fnResponse
                ) {
                    // Error in request
                    Log.e("", "Volley error: $it")
                    CustomViewDialog(
                        R.layout.dialog_serveur_inaccessible, null, ::endSession
                    ).show(supportFragmentManager, "test")
                }
                request.retryPolicy = DefaultRetryPolicy(
                    DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                    0, // DefaultRetryPolicy.DEFAULT_MAX_RETRIES = 2
                    1f // DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
                queue.add(request)

            }
        }
    }

    fun postSomeData(path: String, settings: JSONObject, response: Response.Listener<JSONObject>) {
        mStateManager!!.current.performActionWithFreshTokens(
            mAuthService!!
        ) { accessToken: String?, idToken: String?, ex: AuthorizationException? ->
            if (accessToken == null) {
                Log.e(TAG, "Token refresh failed when fetching user info")
                mUserInfoJson.set(null)
            } else {
                val queue = Volley.newRequestQueue(this)
                val request = JsonObjectRequest(
                    Request.Method.POST,
                    mConfiguration?.restApiUrl.toString() + path + "?access_token=" + accessToken,
                    settings,
                    response
                ) {
                    // Error in request
                    Log.e("", "Volley error: $it")
                    CustomViewDialog(
                        R.layout.dialog_serveur_inaccessible, null, ::endSession
                    ).show(supportFragmentManager, "test")
                }
                queue.add(request)
            }
        }
    }

}