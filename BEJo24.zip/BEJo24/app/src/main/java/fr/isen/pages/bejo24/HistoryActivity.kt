package fr.isen.pages.bejo24

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import fr.isen.pages.bejo24.adapter.HistoryAdapter
import fr.isen.pages.bejo24.databinding.ActivityHistoryBinding
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.enum.EnumSeekBar
import fr.isen.pages.bejo24.helper.EnumHelper
import fr.isen.pages.bejo24.model.History
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : MenuActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private var listSB = listOf(R.id.dialogHistoryIntensitySB)
    private var listHistories: List<History> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val addButton = binding.activityHistoryAdd
        addButton.setOnClickListener {
            CustomFormDialog(
                R.layout.dialog_add_history,
                ::actionButtonValid,
                null,
                listSB,
                ::actionChangeValue,
                ::actionFillingSpinner
            ).show(supportFragmentManager, "test")
        }
        getHistoryBdd()
        listHistories = ArrayList()
    }

    private fun display() {
        listHistories = listHistories.sortedByDescending { it.date }
        binding.activityHistoryRV.layoutManager = LinearLayoutManager(this)
        binding.activityHistoryRV.adapter = HistoryAdapter(listHistories)
        listHistories = ArrayList()
    }

    private fun getHistoryBdd() {
        getSomeData("injuries") { response ->
            val historyArray = response.getJSONArray("data")
            Log.i("said", historyArray.toString())
            if (historyArray.length() != 0) {
                for (i in 0 until historyArray.length()) {
                    val histories = historyArray.getJSONArray(i)
                    if (histories[4].toString().toInt() > 4) {
                        val history = History(
                            choice = histories[2].toString(),
                            date = histories[3].toString(),
                            intensite = histories[4].toString()
                        )

                        listHistories = listHistories + history
                    }
                }
            }
            display()
        }
    }

    private fun actionButtonValid(customView: View) {
        val date = customView.findViewById<DatePicker>(R.id.dialogHistoryDate)
        val day: Int = date.dayOfMonth
        val month: Int = date.month
        val year: Int = date.year
        val calendar = Calendar.getInstance()
        calendar[year, month] = day
        val format = SimpleDateFormat("yyyy/MM/dd",Locale.US)
        val formattedDate: String = format.format(calendar.time)

        val jsonObject = JSONObject()
        jsonObject.put(
            "Position",
            customView.findViewById<Spinner>(R.id.dialogHistoryChoice).selectedItem.toString()
        )
        jsonObject.put("Date", formattedDate)
        jsonObject.put(
            "Intensity",
            customView.findViewById<TextView>(R.id.dialogHistoryIntensityValeur).text.toString()
        )
        jsonObject.put("Injury_status", 0)

        postSomeData("injuries", jsonObject) {
            getHistoryBdd()
        }
    }

    private fun actionChangeValue(customView: View, enum: EnumSeekBar) {
        val idSeekbar = (object : EnumHelper() {}).convertEnumSeekBarToIdSeekBar(enum)
        val idText = (object : EnumHelper() {}).convertIdSeekBarToIdText(idSeekbar)
        val value = customView.findViewById<SeekBar>(idSeekbar).progress
        customView.findViewById<TextView>(idText).text = value.toString()
    }

    private fun actionFillingSpinner(customView: View) {
        val listPartiesCorps = resources.getStringArray(R.array.Body)
        val spinner = customView.findViewById<Spinner>(R.id.dialogHistoryChoice)
        if (spinner != null) {
            spinner.adapter =
                ArrayAdapter(this, android.R.layout.simple_spinner_item, listPartiesCorps)
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View,
                    position: Int,
                    id: Long
                ) {

                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
        }
    }
}