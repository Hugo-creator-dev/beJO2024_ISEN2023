package fr.isen.pages.bejo24.dialog

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.View
import androidx.fragment.app.DialogFragment

open class CustomViewDialog(
    val layout: Int,
    private val view: ((view: View) -> Unit)?,
    private val endSession: (() -> Unit)?
) : DialogFragment() {
    private lateinit var customView: View

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            customView = requireActivity().layoutInflater.inflate(layout, null)
            view?.let { it1 -> it1(customView) }
            builder.setView(customView)
            builder.setPositiveButton("Fermer") { _, _ ->
                endSession?.let { it1 -> it1() }
            }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}