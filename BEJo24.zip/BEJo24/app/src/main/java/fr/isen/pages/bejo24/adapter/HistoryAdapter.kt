package fr.isen.pages.bejo24.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.viewHolder.HistoryViewHolder
import fr.isen.pages.bejo24.databinding.RvHistoryBinding
import fr.isen.pages.bejo24.model.History

class HistoryAdapter(private val histories: List<History>) :
    RecyclerView.Adapter<HistoryViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        return HistoryViewHolder(
            RvHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val history = histories[position]
        holder.zone.text = history.choice
        holder.date.text = history.date
        holder.intensity.text = history.intensite
    }

    override fun getItemCount(): Int {
        return histories.size
    }
}