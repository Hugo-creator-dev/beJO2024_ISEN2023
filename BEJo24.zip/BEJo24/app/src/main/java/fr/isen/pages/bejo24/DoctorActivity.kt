package fr.isen.pages.bejo24

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import fr.isen.pages.bejo24.adapter.DoctorAdapter
import fr.isen.pages.bejo24.databinding.ActivityDoctorBinding
import fr.isen.pages.bejo24.dialog.CustomViewDialog
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.helper.TextValidatorHelper
import fr.isen.pages.bejo24.model.Doctor
import org.json.JSONObject

class DoctorActivity : MenuActivity() {
    private lateinit var binding: ActivityDoctorBinding
    private var listDoctors: List<Doctor> = ArrayList()
    private var selectedDoctor: Doctor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDoctorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val addButton = binding.activityDoctorAdd
        addButton.setOnClickListener {
            CustomFormDialog(
                R.layout.dialog_add_doctor,
                ::actionButtonValid,
                ::actionValidationText,
                null,
                null,
                null
            ).show(supportFragmentManager, "test")
        }
        getDoctorBdd()
        listDoctors = ArrayList()
    }

    private fun display() {
        listDoctors = listDoctors.sortedByDescending { it.nomDoctor }
        binding.activityDoctorRV.layoutManager = LinearLayoutManager(this)
        binding.activityDoctorRV.adapter = DoctorAdapter(listDoctors, ::actionCommunicationButton)
        listDoctors = ArrayList()
    }

    private fun getDoctorBdd() {
        getSomeData("staff") { response ->
            val doctorArray = response.getJSONArray("data")
            if (doctorArray.length() != 0) {
                for (i in 0 until doctorArray.length()) {
                    val doctors = doctorArray.getJSONArray(i)
                    val doctor = Doctor(
                        nomDoctor = doctors[2].toString().replaceFirstChar { it.uppercase() },
                        prenomDoctor = doctors[1].toString().replaceFirstChar { it.uppercase() },
                        description = doctors[3].toString(),
                        telephone = doctors[4].toString(),
                        mail = doctors[5].toString()
                    )

                    listDoctors = listDoctors + doctor
                }
            }
            display()
        }
    }

    private fun actionButtonValid(customView: View) {
        //add to bdd
        val jsonObject = JSONObject()
        jsonObject.put(
            "Name",
            customView.findViewById<EditText>(R.id.dialogDoctorPrenom).text.toString()
        )
        jsonObject.put(
            "FamilyName",
            customView.findViewById<EditText>(R.id.dialogDoctorNom).text.toString()
        )
        jsonObject.put(
            "Speciality",
            customView.findViewById<EditText>(R.id.dialogDoctorDescription).text.toString()
        )
        jsonObject.put(
            "Phone_number",
            customView.findViewById<EditText>(R.id.dialogDoctorTelephone).text.toString()
        )
        jsonObject.put(
            "email",
            customView.findViewById<EditText>(R.id.dialogDoctorEmail).text.toString()
        )
        jsonObject.put("NomSportif", "Bernard")
        jsonObject.put("PrenomSportif", "Jean")

        postSomeData("staff", jsonObject) {
            getDoctorBdd()
        }
    }

    private fun actionCommunicationButton(doctor: Doctor) {
        selectedDoctor = doctor
        CustomViewDialog(
            R.layout.dialog_communication_doctor,
            ::viewCommunicationDoctor,
            null
        ).show(supportFragmentManager, "test")
    }

    private fun viewCommunicationDoctor(customView: View) {
        if (selectedDoctor != null) {
            val nomPrenom = selectedDoctor!!.nomDoctor + " " + selectedDoctor!!.prenomDoctor
            customView.findViewById<TextView>(R.id.dialogComDoctorNomPrenom).text = nomPrenom
            customView.findViewById<TextView>(R.id.dialogComDoctorDescription).text =
                selectedDoctor!!.description
            customView.findViewById<TextView>(R.id.dialogComDoctorTelephone).text =
                selectedDoctor!!.telephone
            customView.findViewById<TextView>(R.id.dialogComDoctorEmail).text =
                selectedDoctor!!.mail
            selectedDoctor = null
        }
    }

    private fun actionValidationText(customView: View, dialog: AlertDialog) {
        val dictionary = hashMapOf(
            R.id.dialogDoctorNom to false,
            R.id.dialogDoctorPrenom to false,
            R.id.dialogDoctorDescription to false,
            R.id.dialogDoctorTelephone to false,
            R.id.dialogDoctorEmail to false,
        )

        dictionary.forEach {
            val textView = customView.findViewById<TextView>(R.id.dialogDoctorValidator)
            customView.findViewById<EditText>(it.key).addTextChangedListener(
                object : TextValidatorHelper(textView, dialog) {
                    override fun isFormValid(isTextValid: Boolean): Boolean {
                        dictionary[it.key] = isTextValid
                        return !dictionary.containsValue(false)
                    }
                }
            )
        }
    }
}