package fr.isen.pages.bejo24.helper

import fr.isen.pages.bejo24.R
import fr.isen.pages.bejo24.enum.EnumStatGeneral
import fr.isen.pages.bejo24.enum.EnumSeekBar

open class EnumHelper {
    fun convertEnumStatGeneralStringToInt(valour: String): Int {
        return when (valour) {
            EnumStatGeneral.TresBon.toString() -> 4
            EnumStatGeneral.Bon.toString() -> 3
            EnumStatGeneral.Neutre.toString() -> 2
            EnumStatGeneral.Mauvais.toString() -> 1
            EnumStatGeneral.TresMauvais.toString() -> 0
            else -> -1
        }
    }

    fun convertIntToEnumStatGeneralString(valour: Int): String {
        return when (valour) {
            0 -> EnumStatGeneral.TresMauvais.toString()
            1 -> EnumStatGeneral.Mauvais.toString()
            2 -> EnumStatGeneral.Neutre.toString()
            3 -> EnumStatGeneral.Bon.toString()
            4 -> EnumStatGeneral.TresBon.toString()
            else -> "error"
        }
    }

    fun convertIntToEnumSeekBar(id: Int): EnumSeekBar {
        return when (id) {
            R.id.dialogGeneralSommeilSB -> EnumSeekBar.Sommeil
            R.id.dialogGeneralFatigueSB -> EnumSeekBar.Fatigue
            R.id.dialogGeneralCourbatureSB -> EnumSeekBar.Courbature
            R.id.dialogGeneralHumeurSB -> EnumSeekBar.Humeur
            R.id.dialogPhysiqueSB -> EnumSeekBar.Physique
            R.id.dialogHistoryIntensitySB -> EnumSeekBar.Blessure
            else -> EnumSeekBar.Default // error
        }
    }

    fun convertEnumSeekBarToIdSeekBar(enum: EnumSeekBar): Int {
        return when (enum) {
            EnumSeekBar.Sommeil -> R.id.dialogGeneralSommeilSB
            EnumSeekBar.Fatigue -> R.id.dialogGeneralFatigueSB
            EnumSeekBar.Courbature -> R.id.dialogGeneralCourbatureSB
            EnumSeekBar.Humeur -> R.id.dialogGeneralHumeurSB
            EnumSeekBar.Physique -> R.id.dialogPhysiqueSB
            EnumSeekBar.Blessure -> R.id.dialogHistoryIntensitySB
            EnumSeekBar.Default -> -1 // error
        }
    }

    fun convertIdSeekBarToIdText(seekbar: Int): Int {
        return when (seekbar) {
            R.id.dialogGeneralSommeilSB -> R.id.dialogGeneralSommeilValeur
            R.id.dialogGeneralFatigueSB -> R.id.dialogGeneralFatigueValeur
            R.id.dialogGeneralCourbatureSB -> R.id.dialogGeneralCourbatureValeur
            R.id.dialogGeneralHumeurSB -> R.id.dialogGeneralHumeurValeur
            R.id.dialogPhysiqueSB -> R.id.dialogPhysiqueValeur
            R.id.dialogHistoryIntensitySB -> R.id.dialogHistoryIntensityValeur
            else -> -1 // error
        }
    }
}