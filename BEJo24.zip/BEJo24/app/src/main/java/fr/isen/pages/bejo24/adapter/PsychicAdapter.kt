package fr.isen.pages.bejo24.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.viewHolder.PsychicViewHolder
import fr.isen.pages.bejo24.databinding.RvFacteurBinding
import fr.isen.pages.bejo24.model.Psychique

class PsychicAdapter(
    private val psychiatrizes: List<Psychique>,
    val onLessClick: (Psychique) -> Unit,
    val onMoreClick: (Psychique) -> Unit
) : RecyclerView.Adapter<PsychicViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PsychicViewHolder {
        return PsychicViewHolder(
            RvFacteurBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: PsychicViewHolder, position: Int) {
        val psychic = psychiatrizes[position]
        holder.facteur.text = psychic.nomFacteur
        holder.textChoice.text = psychic.impact

        holder.minusButton.setOnClickListener {
            onLessClick(psychic)
        }
        holder.plusButton.setOnClickListener {
            onMoreClick(psychic)
        }
    }

    override fun getItemCount(): Int {
        return psychiatrizes.size
    }
}