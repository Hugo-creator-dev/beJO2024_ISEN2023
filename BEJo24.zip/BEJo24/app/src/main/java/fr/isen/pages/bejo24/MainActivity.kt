package fr.isen.pages.bejo24

import android.content.Intent
import android.os.Bundle
import android.util.Log
import fr.isen.pages.bejo24.databinding.ActivityMainBinding
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationResponse

class MainActivity : MenuActivity() {
    private lateinit var binding: ActivityMainBinding

    //ngrok-skip-browser-warning
    //
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val stateButton = binding.activityMainState
        val trainingButton = binding.activityMainTraining
        val adviceButton = binding.activityMainAdvice
        val doctorButton = binding.activityMainDoctor

        stateButton.setOnClickListener {
            startActivity(Intent(this, MyStateActivity::class.java))
        }

        trainingButton.setOnClickListener {
            startActivity(Intent(this, TrainingActivity::class.java))
        }

        adviceButton.setOnClickListener {
            startActivity(Intent(this, AdviceActivity::class.java))
        }

        doctorButton.setOnClickListener {
            startActivity(Intent(this, DoctorActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()

        if (mStateManager?.current?.isAuthorized == true)
            return
        // the stored AuthState is incomplete, so check if we are currently receiving the result of
        // the authorization flow from the browser.
        val response = AuthorizationResponse.fromIntent(intent)
        val ex = AuthorizationException.fromIntent(intent)

        if (response != null || ex != null) {
            mStateManager!!.updateAfterAuthorization(response, ex)
        }
        if (response?.authorizationCode != null) {

            // authorization code exchange is required
            mStateManager!!.updateAfterAuthorization(response, ex)
            exchangeAuthorizationCode(response) {
                getSomeData("identity") { response ->
                    val data = response.getJSONArray("data")
                    Log.i("data", data.toString())
                    if (data.length() == 0) {
                        startActivity(Intent(this, FirstStepActivity::class.java))
                    } else {
                        //TODO: print info
                    }
                }
            }
        } else if (ex != null) {

        } else {

        }
    }

    override fun onSaveInstanceState(state: Bundle) {
        super.onSaveInstanceState(state)
        // user info is retained to survive activity restarts, such as when rotating the
        // device or switching apps. This isn't essential, but it helps provide a less
        // jarring UX when these events occur - data does not just disappear from the view.
        if (mUserInfoJson.get() != null) {
            state.putString(KEY_USER_INFO, mUserInfoJson.toString())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mAuthService!!.dispose()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == END_SESSION_REQUEST_CODE && resultCode == RESULT_OK) {
            signOut()
            finish()
        } else {

        }
    }

}