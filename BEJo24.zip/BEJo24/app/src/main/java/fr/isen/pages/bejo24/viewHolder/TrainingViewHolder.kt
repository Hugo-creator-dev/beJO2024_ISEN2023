package fr.isen.pages.bejo24.viewHolder

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.databinding.RvTrainingBinding

class TrainingViewHolder(binding : RvTrainingBinding) : RecyclerView.ViewHolder(binding.root) {
    val sport: TextView = binding.rvTrainingSport
    val description: TextView = binding.rvTrainingDescription
    val date: TextView = binding.rvTrainingDate
    val duree: TextView = binding.rvTrainingTime
}