package fr.isen.pages.bejo24.model

import java.io.Serializable

data class Psychique(
    val nomFacteur: String,
    var impact: String
) : Serializable

data class Training(
    val sport: String,
    val description: String,
    val date: String,
    val duree: String
) : Serializable

data class Doctor(
    val nomDoctor: String,
    val prenomDoctor: String,
    val description: String,
    val mail: String,
    val telephone: String
) : Serializable

data class Physique(
    val zoneDouleur: String,
    val intensite: Int
) : Serializable

data class General(
    var sommeil: Int,
    var fatigue: Int,
    var courbature: Int,
    var humeur: Int,
    var poids: String
) : Serializable

data class History(
    val choice: String,
    val date: String,
    val intensite: String
) : Serializable

data class Conseil(
    val titre: String,
    val description: String
) : Serializable