package fr.isen.pages.bejo24.helper

import android.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.widget.TextView
import androidx.core.view.isVisible

abstract class TextValidatorHelper(
    private var textView: TextView,
    private var dialog: AlertDialog
) : TextWatcher {
    abstract fun isFormValid(isTextValid: Boolean): Boolean

    override fun afterTextChanged(s: Editable) {
        val isValid = isFormValid(s.toString() != "")
        textView.isVisible = !isValid
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = isValid
    }

    override fun beforeTextChanged(
        s: CharSequence,
        start: Int,
        count: Int,
        after: Int
    ) { /* Don't care */
    }

    override fun onTextChanged(
        s: CharSequence,
        start: Int,
        before: Int,
        count: Int
    ) { /* Don't care */
    }
}