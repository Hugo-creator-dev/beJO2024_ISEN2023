package fr.isen.pages.bejo24.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.isen.pages.bejo24.viewHolder.DoctorViewHolder
import fr.isen.pages.bejo24.databinding.RvDoctorBinding
import fr.isen.pages.bejo24.model.Doctor

class DoctorAdapter(
    private val doctors: List<Doctor>,
    val onCommunicationImgClick: (doctor: Doctor) -> Unit
) : RecyclerView.Adapter<DoctorViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        return DoctorViewHolder(
            RvDoctorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val doctor = doctors[position]
        holder.nom.text = doctor.nomDoctor
        holder.prenom.text = doctor.prenomDoctor
        holder.description.text = doctor.description

        holder.communicationImg.setOnClickListener {
            onCommunicationImgClick(doctor)
        }
    }

    override fun getItemCount(): Int {
        return doctors.size
    }
}