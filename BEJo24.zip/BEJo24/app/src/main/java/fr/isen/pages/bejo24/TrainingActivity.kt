package fr.isen.pages.bejo24

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import fr.isen.pages.bejo24.adapter.TrainingAdapter
import fr.isen.pages.bejo24.databinding.ActivityTrainingBinding
import fr.isen.pages.bejo24.dialog.CustomFormDialog
import fr.isen.pages.bejo24.helper.TextValidatorHelper
import fr.isen.pages.bejo24.model.Training
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class TrainingActivity : MenuActivity() {
    private lateinit var binding: ActivityTrainingBinding
    private var listTraining: List<Training> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTrainingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val addButton = binding.activityTrainingAdd
        addButton.setOnClickListener {
            CustomFormDialog(
                R.layout.dialog_add_training,
                ::actionButtonValid,
                ::actionValidationText,
                null,
                null,
                null
            ).show(supportFragmentManager, "test")
        }
        getTrainingBdd()
        listTraining = ArrayList()
    }

    private fun display() {
        listTraining = listTraining.sortedByDescending { it.date }
        binding.activityTrainingRV.layoutManager = LinearLayoutManager(this)
        binding.activityTrainingRV.adapter = TrainingAdapter(listTraining)
        listTraining = ArrayList()
    }

    private fun getTrainingBdd() {
        getSomeData(
            "trainingstat"
        ) { response ->
            val trainingArray = response.getJSONArray("data")
            if (trainingArray.length() != 0) {
                for (i in 0 until trainingArray.length()) {
                    val trainings = trainingArray.getJSONArray(i)
                    val duree = trainings[5].toString()
                    val hour = duree.toInt() / 60
                    val minute = duree.toInt() % 60

                    val training = Training(
                        sport = trainings[2].toString(),
                        description = trainings[3].toString(),
                        date = trainings[4].toString(),
                        duree = hour.toString() + "h" + minute.toString()
                    )

                    listTraining = listTraining + training
                }
            }
            display()
        }
    }

    private fun actionButtonValid(customView: View) {
        //date
        val date = customView.findViewById<DatePicker>(R.id.dialogTrainingDate)
        val day: Int = date.dayOfMonth
        val month: Int = date.month
        val year: Int = date.year
        val calendar = Calendar.getInstance()
        calendar[year, month] = day
        val format = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        val formattedDate: String = format.format(calendar.time)


        val hour =
            customView.findViewById<EditText>(R.id.dialogTrainingHeure).text.toString().toInt()
        val minute =
            customView.findViewById<EditText>(R.id.dialogTrainingMinute).text.toString().toInt()
        val duree = hour * 60 + minute

        //add to bdd
        val jsonObject = JSONObject()
        jsonObject.put("Date", formattedDate)
        jsonObject.put(
            "Title", customView.findViewById<EditText>(R.id.dialogTrainingSport).text.toString()
        )
        jsonObject.put(
            "Description",
            customView.findViewById<EditText>(R.id.dialogTrainingDescription).text.toString()
        )
        jsonObject.put("Duration_time", duree)
        jsonObject.put("Intensity_of_last_training", 1)

        postSomeData("trainingstat", jsonObject) {
            getTrainingBdd()
        }
    }

    private fun actionValidationText(customView: View, dialog: AlertDialog) {
        val dictionary = hashMapOf(
            R.id.dialogTrainingSport to false,
            R.id.dialogTrainingDescription to false,
            R.id.dialogTrainingHeure to false,
            R.id.dialogTrainingMinute to false,
        )

        dictionary.forEach {
            val textView = customView.findViewById<TextView>(R.id.dialogTrainingValidator)
            customView.findViewById<EditText>(it.key)
                .addTextChangedListener(object : TextValidatorHelper(textView, dialog) {
                    override fun isFormValid(isTextValid: Boolean): Boolean {
                        dictionary[it.key] = isTextValid
                        return !dictionary.containsValue(false)
                    }
                })
        }
    }
}